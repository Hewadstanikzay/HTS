import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import OpenAI from "openai";

dotenv.config();
const app = express();
app.use(cors());
app.use(express.json());

const client = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
  baseURL: process.env.NGROK_AI_BASEURL || "https://api.openai.com/v1"
});

app.get("/", (req, res) => res.send("🚀 Hewad.TS AI Server is running!"));

app.post("/chat", async (req, res) => {
  try {
    const user = (req.body?.message || "سلام! خودت را معرفی کن.").toString();
    const completion = await client.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        { role: "system", content: "You are Hewad.TS AI assistant." },
        { role: "user", content: user }
      ]
    });
    res.json({ reply: completion.choices?.[0]?.message?.content || "" });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: e.message });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`✅ Server running at http://localhost:${PORT}`));