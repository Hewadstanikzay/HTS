# Hewad.TS AI Server (Node.js)

## نصب
```bash
npm install
```

## اجرا
```bash
npm run dev
```

## متغیرهای محیطی
بر اساس `.env.example` یک `.env` بسازید.

## تست
مرورگر:
http://localhost:3000/test.html
